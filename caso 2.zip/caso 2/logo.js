for(var i=1){
    document.body.innerHTML+="<marquee behavior='alternate' SCROOLLAMOUNT=1><div id='logo'></marquee>
}